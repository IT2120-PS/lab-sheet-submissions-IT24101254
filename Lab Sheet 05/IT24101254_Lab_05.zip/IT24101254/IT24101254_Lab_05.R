#Question 01
setwd("C:\\Users\\IT24101254\\Downloads\\IT24101254")
getwd()

Delivery_Times <- read.table("Exercise - Lab 05.txt" ,header=TRUE,sep = ",")

#Question_02

histogram <- hist(Delivery_Times$Delivery_Time_.minutes., 
     main = "Histogram of Delivery Times",
     xlab = "Frequency",
     ylab = "Delivery_Time",
     col = "skyblue",
     breaks = seq(20,70,length = 10))

#Question_04
breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids

classes <- c()

for(i in 1 :length(breaks)-1){
  classes[i] <- paste0("[",breaks[i],",",breaks[i-1],")")
}

cbind(Classes=classes, Frequency = frequency)

lines(mids, freq)

cum.freq <- cumsum(freq)

new <- c()
for(i in 1: length(breaks)){
  if(i==1){
    new[i]=0
  } else{
    new[i]=cum.freq[i-1]
  }
}

plot(breaks, new, type = 'o', main = "Cumulative Frequency Polygon for Delivery Time",
     xlab= "Frequency",
     ylab= "Delivery Time",
     ylim = c(0,max(cum.freq)))
cbind(Upper = breaks, CumFreq = new)

